<?php

session_start();

if (!isset($_SESSION['customer_id'])) {
  header("Location: ./login.php");
  exit();
}

require_once('data/customer.php');

$customer = find_customer_with_id($_SESSION['customer_id']);

require('layouts/header.php');

?>

<link rel="stylesheet" href="./assets/css/profile.css">

<main>
  <div class="profile container">
    <div class="profile__header">
      <h1>My Profile</h1>
    </div>
    <div class="profile__body">
      <div class="profile__right">
        <div class="profile__form">
          <div>
            <div class="input-label">Name:</div>
            <div class="input-label"><?= $customer['customer_name'] ?></div>
          </div>
          <div>
            <div class="input-label">Email:</div>
            <div class="input-label"><?= $customer['customer_email'] ?></div>
          </div>
          <div>
            <div class="input-label">Phone:</div>
            <div class="input-label"><?= $customer['customer_phone'] ?></div>
          </div>
          <form action="./editprofile.php" method="get">
            <button type="submit" class="profile__button">Update</button>
          </form>
        </div>
      </div>
    </div>
  </div>
</main>

<?php

require('layouts/footer.php');

?>