SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

CREATE TABLE `cart_items` (
  `customer_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `cart_item_qty` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `categories` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`category_id`, `category_name`) VALUES
(1, 'Accessories'),
(2, 'Gear Parts'),
(3, 'Parts'),
(4, 'Helmet');


CREATE TABLE `customers` (
  `customer_id` int(11) NOT NULL,
  `customer_name` varchar(255) NOT NULL,
  `customer_phone` varchar(17) NOT NULL,
  `customer_email` varchar(255) NOT NULL,
  `customer_password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


INSERT INTO `customers` (`customer_id`, `customer_name`, `customer_phone`, `customer_email`, `customer_password`) VALUES
(1, 'Credo', '081234567891', 'credo@example.com', '$2y$10$YpsuVarBbWQP9bDd4K4pI.JjpAP.unxUWAsS/XJHofTR/PdcEV8Bu'),
(2, 'Gwen Chana', '09197345894', 'gwenchana@example.com', '$2y$10$YpsuVarBbWQP9bDd4K4pI.JjpAP.unxUWAsS/XJHofTR/PdcEV8Bu');


CREATE TABLE `items` (
  `item_id` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `item_price` int(11) NOT NULL,
  `item_stock` int(11) NOT NULL,
  `item_photo` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `items` (`item_id`, `supplier_id`, `category_id`, `item_name`, `item_price`, `item_stock`, `item_photo`) VALUES
(1, 1, 4, 'Alpinestar White', 50000, 20, '655eea074f000.jpg'),
(2, 1, 1, 'Monimoto M GPS AntiTheft Tracker', 6799, 15, '655eeb2c4929e.jpg'),
(3, 1, 1, 'HelmetLok II Helmet Lock', 1599, 15, '655eed4066c32.jpeg'),
(4, 1, 1, 'Dainese Key Ring', 250, 12, '655eed59ed050.jpg'),
(5, 1, 1, 'Cardo PackTalk Edge Headset', 14000, 13, '655eef0382fe4.jpg'),
(6, 2, 2, 'Forma Adventure Boots', 13499, 16, '655eef3c6c515.jpg'),
(7, 2, 2, 'Alpinestars Sektor Vented Shoes', 6000, 18, '655eef669e1eb.jpg'),
(10, 2, 2, 'Alpinestars T-GP Plus', 13500, 13, '655ef006584e5.jpg'),
(12, 3, 3, 'SS Cycle Replacement Air Filter', 2499, 20, '655f184e3e176.jpg'),
(13, 3, 3, 'Yuasa Battery Vent Tube', 100, 23, '65601b3b0fff0.jpg'),
(14, 3, 3, 'CRG Arrow Bar End Mirror', 10000, 13, '65601b8dd7bc1.jpg'),
(15, 4, 4, 'BILT Techno', 9980, 5, '6560397845cc61.jpg'),
(16, 4, 4, 'Bell Broozer', 12500, 11, '656039cc98fdf.jpg'),
(17, 4, 4, 'Shoei Neotec', 30000, 13, '656039f17b993.jpg'),
(18, 4, 4, 'Bell Qualifier DLX Mips', 10000, 4, '65603a5a2c572.jpg'),
(19, 4, 4, 'SEDICI STRADA', 5000, 8, '65603a9c34bad.jpeg'),
(22, 4, 2, 'Klim AI AIR', 3500, 7, '6560397845cc6.jpg');

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `payment_method_id` int(11) NOT NULL,
  `order_date` date NOT NULL,
  `order_status` varchar(50) NOT NULL,
  `order_total_price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `orders` (`order_id`, `customer_id`, `payment_method_id`, `order_date`, `order_status`, `order_total_price`) VALUES
(1, 1, 1, '2023-11-17', 'paid', 40000),
(2, 2, 2, '2023-11-17', 'paid', 100000),
(3, 2, 3, '2023-11-19', 'paid', 120000),
(4, 2, 3, '2024-05-21', 'paid', 63000),
(5, 2, 1, '2024-05-21', 'unpaid', 200000),
(6, 2, 3, '2024-05-21', 'unpaid', 179000),
(7, 2, 3, '2024-05-21', 'unpaid', 35000),
(8, 2, 2, '2024-05-22', 'unpaid', 30000);


CREATE TABLE `order_details` (
  `order_detail_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `order_detail_qty` int(11) NOT NULL,
  `order_detail_unit_price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `order_details` (`order_detail_id`, `order_id`, `item_id`, `order_detail_qty`, `order_detail_unit_price`) VALUES
(1, 1, 3, 1, 20000),
(2, 1, 7, 2, 10000),
(3, 2, 12, 2, 50000),
(4, 3, 2, 1, 75000),
(5, 3, 3, 1, 20000),
(6, 3, 4, 1, 25000),
(7, 4, 19, 1, 29000),
(8, 4, 18, 1, 34000),
(9, 5, 12, 4, 50000),
(10, 6, 19, 5, 29000),
(11, 6, 15, 1, 24000),
(12, 6, 7, 1, 10000),
(13, 7, 10, 1, 35000),
(14, 8, 19, 6, 5000);

CREATE TABLE `payment_methods` (
  `payment_method_id` int(11) NOT NULL,
  `payment_method_name` varchar(255) NOT NULL,
  `payment_method_number` varchar(50) NOT NULL,
  `payment_method_bank` varchar(50) NOT NULL,
  `payment_method_logo` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `payment_methods` (`payment_method_id`, `payment_method_name`, `payment_method_number`, `payment_method_bank`, `payment_method_logo`) VALUES
(1, 'Luci Moto PH', '673892017384', 'BPI', 'bpi.svg'),
(2, 'Luci Moto PH', '923456129083', 'GCASH', 'gcash-svgrepo-com.svg'),
(3, 'Luci Moto PH', '384789263892', 'Cash on Delivery', 'cash-on-delivery.svg');

CREATE TABLE `roles` (
  `role_id` int(11) NOT NULL,
  `role_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `roles` (`role_id`, `role_name`) VALUES
(1, 'administrator'),
(2, 'manager');

CREATE TABLE `staffs` (
  `staff_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `staff_name` varchar(255) NOT NULL,
  `staff_phone` varchar(17) NOT NULL,
  `staff_email` varchar(255) NOT NULL,
  `staff_password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `staffs` (`staff_id`, `role_id`, `staff_name`, `staff_phone`, `staff_email`, `staff_password`) VALUES
(1, 1, 'Gabriel Eduria', '081234567891', 'gabriel@example.com', '$2y$10$YpsuVarBbWQP9bDd4K4pI.JjpAP.unxUWAsS/XJHofTR/PdcEV8Bu'),
(2, 2, 'Umar Muchtar', '081234567891', 'umar@example.com', '$2y$10$YpsuVarBbWQP9bDd4K4pI.JjpAP.unxUWAsS/XJHofTR/PdcEV8Bu');

CREATE TABLE `suppliers` (
  `supplier_id` int(11) NOT NULL,
  `supplier_name` varchar(255) NOT NULL,
  `supplier_phone` varchar(17) NOT NULL,
  `supplier_address` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `suppliers` (`supplier_id`, `supplier_name`, `supplier_phone`, `supplier_address`) VALUES
(1, 'PT Nusa Bangsa', '081234567891', 'Jl. Semarang No. 33 Surabaya'),
(2, 'PT Taman Indah', '081234567891', 'Jl. Pahlawan No. 17 Bangkalan'),
(3, 'PT Kebun Merdeka', '081234567891', 'Jl. Telang Indah No. 19 Bangkalan'),
(4, 'PT Rumput Hijau', '081234567891', 'Jl. Cempaka No. 27 Surabaya');

ALTER TABLE `cart_items`
  ADD PRIMARY KEY (`customer_id`,`item_id`),
  ADD KEY `FK_cart_item_plant` (`item_id`);

ALTER TABLE `categories`
  ADD PRIMARY KEY (`category_id`);

ALTER TABLE `customers`
  ADD PRIMARY KEY (`customer_id`);

ALTER TABLE `items`
  ADD PRIMARY KEY (`item_id`),
  ADD KEY `FK_category_plant` (`category_id`),
  ADD KEY `FK_plant_supplier` (`supplier_id`);

ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `FK_customer_order` (`customer_id`),
  ADD KEY `FK_payment_method_order` (`payment_method_id`);

ALTER TABLE `order_details`
  ADD PRIMARY KEY (`order_detail_id`),
  ADD KEY `FK_order_detail_order` (`order_id`),
  ADD KEY `FK_order_detail_plant` (`item_id`);

ALTER TABLE `payment_methods`
  ADD PRIMARY KEY (`payment_method_id`);

ALTER TABLE `roles`
  ADD PRIMARY KEY (`role_id`);

ALTER TABLE `staffs`
  ADD PRIMARY KEY (`staff_id`),
  ADD KEY `FK_role_staff` (`role_id`);

ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`supplier_id`);

ALTER TABLE `categories`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

ALTER TABLE `customers`
  MODIFY `customer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

ALTER TABLE `items`
  MODIFY `item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

ALTER TABLE `order_details`
  MODIFY `order_detail_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

ALTER TABLE `payment_methods`
  MODIFY `payment_method_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

ALTER TABLE `roles`
  MODIFY `role_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

ALTER TABLE `staffs`
  MODIFY `staff_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

ALTER TABLE `suppliers`
  MODIFY `supplier_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

ALTER TABLE `cart_items`
  ADD CONSTRAINT `FK_cart_item_customer` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`customer_id`),
  ADD CONSTRAINT `FK_cart_item_plant` FOREIGN KEY (`item_id`) REFERENCES `items` (`item_id`);
  
ALTER TABLE `items`
  ADD CONSTRAINT `FK_category_plant` FOREIGN KEY (`category_id`) REFERENCES `categories` (`category_id`),
  ADD CONSTRAINT `FK_plant_supplier` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`supplier_id`);

ALTER TABLE `orders`
  ADD CONSTRAINT `FK_customer_order` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`customer_id`),
  ADD CONSTRAINT `FK_payment_method_order` FOREIGN KEY (`payment_method_id`) REFERENCES `payment_methods` (`payment_method_id`);

ALTER TABLE `order_details`
  ADD CONSTRAINT `FK_order_detail_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`),
  ADD CONSTRAINT `FK_order_detail_plant` FOREIGN KEY (`item_id`) REFERENCES `items` (`item_id`);

ALTER TABLE `staffs`
  ADD CONSTRAINT `FK_role_staff` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`);
COMMIT;
