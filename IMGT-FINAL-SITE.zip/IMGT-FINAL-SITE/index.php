<?php

session_start();

require('layouts/header.php');

?>

<link rel="stylesheet" href="assets/css/others.css">

<main>
  <div class="hero container">
	<section class="slider">
		<div class="slides">
			<div class="item active" id="slide1">
				<a href="./products.php" class="navbar__link"><img src="assets/img/slider-image1.png" alt="slide1" /></a>
			</div>
			<div class="item" id="slide2">
				<a href="./products.php" class="navbar__link"><img src="assets/img/slider-image2.png" alt="slide2" /></a>
			</div>
			<div class="item" id="slide3">
				<a href="./products.php" class="navbar__link"><img src="assets/img/slider-image3.png" alt="slide3" /></a>
			</div>
			<div class="item" id="slide4">
				<a href="./products.php" class="navbar__link"><img src="assets/img/slider-image4.png" alt="slide4" /></a>
			</div>
		</div>
		<div class="buttons">
			<div class="buttons__wrapper">
				<div class="temp-circle" onclick="slider('slide1')" class="fas fa-circle" aria-hidden="true"></div>
				<div class="temp-circle" onclick="slider('slide2')" class="fas fa-circle" aria-hidden="true"></div>
				<div class="temp-circle" onclick="slider('slide3')" class="fas fa-circle" aria-hidden="true"></div>
				<div class="temp-circle" onclick="slider('slide4')" class="fas fa-circle" aria-hidden="true"></div>
			</div>
		</div>
	</section>
  </div>
  <div class="promotion">
  <section>
			<div class="flex-wrapper">
				<div class="card">
					<img src="assets/img/new-release.png" alt="" class="new-release">
				</div>
				<div class="card">
					<div class="bg-watch">
						<img src="assets/img/alpinestars-white.jpg" alt="" class="watch-img show" color="white">
						<img src="assets/img/apinestars-black.jpg" alt="" class="watch-img" color="black">
					</div>
					<div class="info">
							<div class="color-container">
									<div class="colors">
											<span class="color active" primary="#31394e" color="white"></span>
											<span class="color" primary="#f84848" color="black"></span>
									</div>
							</div>
							<div class="watch-name">
									<h2 class="title">
											REAX SUPERFLY 2 GLOVES <br>
											<span>[STOCKS: 5]</span>
									</h2>
									<span class="price">P1500</span>
							</div>
					</div>
					<a href="./products.php" class="add-to-cart-btn">See more.</a>
				</div>
				<div class="card">
						<div class="bg-watch">
								<img src="assets/img/sedici-strada-white.jpg"" class="watch-img show" color="white">
								<img src="assets/img/sedici-strada.jpg" alt="" class="watch-img" color="black">
						</div>
						<div class="info">
								<div class="color-container">
										<div class="colors">
												<span class="color active" primary="#31394e" color="white"></span>
												<span class="color" primary="#f84848" color="black"></span>
										</div>
								</div>
								<div class="watch-name">
										<h2 class="title">
												SEDICI STRADA VERSION 3 <br>
												<span>[STOCKS: 5]</span>
										</h2>
										<span class="price">P800</span>
								</div>
						</div>
						<a href="./products.php" class="add-to-cart-btn">See more.</a>
				</div>
				<div class="card">
						<div class="bg-watch">
								<img src="assets/img/reax-superfly-2.jpg" alt="" class="watch-img show" color="green">
								<img src="assets/img/apinestars-black.jpg" alt="" class="watch-img" color="black">
						</div>
						<div class="info">
								<div class="color-container">
										<div class="colors">
												<span class="color active" primary="#31394e" color="green"></span>
												<span class="color" primary="#f84848" color="black"></span>
										</div>
								</div>
								<div class="watch-name">
										<h2 class="title">
												REAX SUPERFLY 2 GLOVES <br>
												<span>[STOCKS: 5]</span>
										</h2>
										<span class="price">P800</span>
								</div>
						</div>
						<a href="./products.php" class="add-to-cart-btn">See more.</a>
				</div>
				<div class="card">
						<div class="bg-watch">
								<img src="assets/img/alpinestars-techair-5.jpg" alt="" class="watch-img show" color="gray">
								<img src="assets/img/apinestars-black.jpg" alt="" class="watch-img" color="black">
						</div>
						<div class="info">
								<div class="color-container">
										<div class="colors">
												<span class="color active" primary="#31394e" color="gray"></span>
												<span class="color" primary="#f84848" color="black"></span>
										</div>
								</div>
								<div class="watch-name">
										<h2 class="title">
												ALPINESTAR TECHAIR 5 <br>
												<span>[STOCKS: 5]</span>
										</h2>
										<span class="price">P5000</span>
								</div>
						</div>
						<a href="./products.php" class="add-to-cart-btn">See more.</a>
				</div>
				<div class="card">
						<div class="bg-watch">
								<img src="assets/img/klim-ai-air.jpg" alt="" class="watch-img show" color="green">
								<img src="assets/img/apinestars-black.jpg" alt="" class="watch-img" color="black">
						</div>
						<div class="info">
								<div class="color-container">
										<div class="colors">
												<span class="color active" primary="#31394e" color="green"></span>
												<span class="color" primary="#f84848" color="black"></span>
										</div>
								</div>
								<div class="watch-name">
										<h2 class="title">
												KLIM AI-AIR VERSION 1 <br>
												<span>[STOCKS: 5]</span>
										</h2>
										<span class="price">P3500</span>
								</div>
						</div>
						<a href="./products.php" class="add-to-cart-btn">See more.</a>
				</div>
				<div class="card">
						<div class="bg-watch">
								<img src="assets/img/rekluse-clutch-save.jpg" alt="" class="watch-img show" color="green">
								<img src="assets/img/apinestars-black.jpg" alt="" class="watch-img" color="black">
						</div>
						<div class="info">
								<div class="color-container">
										<div class="colors">
												<span class="color active" primary="#31394e" color="green"></span>
												<span class="color" primary="#f84848" color="black"></span>
										</div>
								</div>
								<div class="watch-name">
										<h2 class="title">
												REAX SUPERFLY 2 GLOVES <br>
												<span>[STOCKS: 5]</span>
										</h2>
										<span class="price">P1000</span>
								</div>
						</div>
						<a href="./products.php" class="add-to-cart-btn">See more.</a>
				</div>
        </div>
    </section>
  </div>
</main>

<script src="main.js"></script>
<script src="slider.js"></script>

<?php

require('layouts/footer.php');

?>