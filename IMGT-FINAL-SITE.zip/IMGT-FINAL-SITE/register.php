<?php

session_start();

if (isset($_SESSION['customer_id'])) {
  header("Location: ./products.php");
  exit();
}

require_once('data/customer.php');
require_once('libs/validation.php');

$errors = [];
$old_inputs = [
  'name' => '',
  'phone' => '',
  'email' => '',
];

if (isset($_POST['submit'])) {
  validate_name($errors, $_POST, 'name');
  validate_phone($errors, $_POST, 'phone');
  validate_email_customer($errors, $_POST, 'email');
  validate_password($errors, $_POST, 'password');

  if (!$errors) {
    save_customer($_POST);
    header('Location: ./login.php?success_message=Akun+berhasil+dibuat,+silahkan+login!');
    exit();
  }

  $old_inputs['name'] = htmlspecialchars($_POST['name']);
  $old_inputs['phone'] = htmlspecialchars($_POST['phone']);
  $old_inputs['email'] = htmlspecialchars($_POST['email']);
}

require('layouts/header.php');

?>

<link rel="stylesheet" href="./assets/css/register.css">

<main>
  <div class="register container">
    <form action="./register.php" method="post" class="register__form">
      <h1>Registration</h1>
      <div>
        <label for="name" class="input-label">Name <span class="text-danger">*</span></label>
        <input type="text" name="name" id="name" class="input" value="<?= $old_inputs['name'] ?>" />
        <?php if (isset($errors['name'])) : ?>
          <div class="input-error"><?= $errors['name'] ?></div>
        <?php endif ?>
      </div>
      <div>
        <label for="email" class="input-label">Email <span class="text-danger">*</span></label>
        <input type="text" name="email" id="email" class="input" value="<?= $old_inputs['email'] ?>" />
        <?php if (isset($errors['email'])) : ?>
          <div class="input-error"><?= $errors['email'] ?></div>
        <?php endif ?>
      </div>
      <div>
        <label for="phone" class="input-label">Phone<span class="text-danger">*</span></label>
        <input type="text" name="phone" id="phone" class="input" value="<?= $old_inputs['phone'] ?>" />
        <?php if (isset($errors['phone'])) : ?>
          <div class="input-error"><?= $errors['phone'] ?></div>
        <?php endif ?>
      </div>
      <div>
        <label for="password" class="input-label">Password <span class="text-danger">*</span></label>
        <input type="password" name="password" id="password" class="input" />
        <?php if (isset($errors['password'])) : ?>
          <div class="input-error"><?= $errors['password'] ?></div>
        <?php endif ?>
      </div>
      <button type="submit" name="submit" class="register__button">Save</button>
      <p>
        Already have an account? <a href="./login.php">Login</a>
      </p>
      <p>
        <a href="./admin/login.php">Login Staff</a>
      </p>
    </form>
  </div>
</main>
