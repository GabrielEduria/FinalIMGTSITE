<?php

session_start();

if (isset($_SESSION['customer_id'])) {
  header("Location: ./products.php");
  exit();
}

require_once('data/customer.php');
require_once('libs/validation.php');

$login_error = null;
$errors = [];
$old_inputs = [
  'email' => '',
];

if (isset($_POST['submit'])) {
  validate_email($errors, $_POST, 'email');
  validate_password($errors, $_POST, 'password');

  if (!$errors) {
    $customer = find_customer($_POST['email']);

    if ($customer) {
      if (password_verify($_POST['password'], $customer['customer_password'])) {
        $_SESSION['customer_id'] = $customer['customer_id'];
        $_SESSION['customer_email'] = $customer['customer_email'];
        header("Location: ./products.php");
        exit();
      }
    }

    $login_error = 'Incorrect email or password!';
  }

  $old_inputs['email'] = htmlspecialchars($_POST['email']);
}

require('layouts/header.php');

?>

<link rel="stylesheet" href="./assets/css/login.css">

<main>
  <div class="login container">
    <form action="./login.php" method="post" class="login__left">
      <h1>Login</h1>
      <?php if ($login_error != null) : ?>
        <div class="alert alert_danger">
          <?= $login_error; ?>
        </div>
      <?php endif; ?>
      <?php if (isset($_GET['success_message'])) : ?>
        <div class="alert alert_success">
          <?= $_GET['success_message']; ?>
        </div>
      <?php endif; ?>
      <div>
        <label for="email" class="input-label">Email <span class="text-danger">*</span></label>
        <input type="text" name="email" id="email" class="input" value="<?= $old_inputs['email'] ?>" />
        <?php if (isset($errors['email'])) : ?>
          <div class="input-error"><?= $errors['email'] ?></div>
        <?php endif; ?>
      </div>
      <div>
        <label for="password" class="input-label">Password <span class="text-danger">*</span></label>
        <input type="password" name="password" id="password" class="input" />
        <div class="input-help">Must contain 8-16 characters with a minimum of 1 uppercase letter, 1 lowercase letter, 1 special character, and must not contain spaces.</div>
        <?php if (isset($errors['password'])) : ?>
          <div class="input-error"><?= $errors['password'] ?></div>
        <?php endif; ?>
      </div>
      <button type="submit" name="submit" class="login__button">Login</button>
      <p>Create Account <a href="./register.php">Signup</a></p>
      <p>
        <a href="./admin/login.php">Login Staff</a>
      </p>
    </form>
  </div>
</main>

