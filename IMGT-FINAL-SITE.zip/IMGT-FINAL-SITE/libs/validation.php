<?php

require_once(__DIR__ . '/../config/staff.php');
require_once(__DIR__ . '/../data/customer.php');
require_once(__DIR__ . '/../data/staff.php');

function is_filled($value)
{
  $value = trim($value);
  return !empty($value);
}

function validate_token(&$errors, $field_list, $field_name)
{
  if (!is_filled($field_list[$field_name])) {
    $errors[$field_name] = 'Required to fill!';
    return false;
  }

  if ($field_list[$field_name] == STAFF_ADMINISTRATOR_TOKEN) {
    return 1;
  }

  if ($field_list[$field_name] == STAFF_MANAGER_TOKEN) {
    return 2;
  }

  $errors[$field_name] = 'Invalid token!';
  return false;
}

function validate_name(&$errors, $field_list, $field_name)
{
  if (!is_filled($field_list[$field_name])) {
    $errors[$field_name] = 'Required to fill!';
    return false;
  }

  $pattern = "/^[a-zA-Z-' ]{1,}+$/";
  if (!preg_match($pattern, $field_list[$field_name])) {
    $errors[$field_name] = 'No special characters!';
    return false;
  }

  return true;
}

function validate_phone(&$errors, $field_list, $field_name)
{
  if (!is_filled($field_list[$field_name])) {
    $errors[$field_name] = 'Required to fill!';
    return false;
  }

  $pattern =  "/^[\d]{10,13}$/"; 
  if (!preg_match($pattern, $field_list[$field_name])) {
    $errors[$field_name] = '10-13 digits! digits';
    return false;
  }

  return true;
}

function validate_alphanum(&$errors, $field_list, $field_name)
{
  if (!is_filled($field_list[$field_name])) {
    $errors[$field_name] = 'Required to fill!';
    return false;
  }

  $pattern = "/^[a-zA-Z]+[0-9]+$/";
  if (!preg_match($pattern, $field_list[$field_name])) {
    $errors[$field_name] = "Input should be letter and numbers only!";
    return false;
  }

  return true;
}

function validate_email(&$errors, $field_list, $field_name)
{
  if (!is_filled($field_list[$field_name])) {
    $errors[$field_name] = 'Required to fill!';
    return false;
  }

  if (preg_match('/\s/', $field_list[$field_name])) {
    $errors[$field_name] = 'Input cannot contain spaces!';
    return false;
  }

  $pattern = '/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/';
  if (!preg_match($pattern, $field_list[$field_name])) {
    $errors[$field_name] = 'Incorrect Email Format';
    return false;
  }

  return true;
}

function validate_email_customer(&$errors, $field_list, $field_name)
{
  if (!is_filled($field_list[$field_name])) {
    $errors[$field_name] = 'Required to fill!';
    return false;
  }

  $customers = get_customers();

  if (isset($_SESSION['customer_id'])) {
    $emailcust = get_email_customer($_SESSION['customer_id']);

    if ($field_list[$field_name] != $emailcust['customer_email']) {
      foreach ($customers as $customer) {
        if ($customer['customer_email'] == $field_list[$field_name]) {
          $errors[$field_name] = 'Existing email, use another one!';
          return false;
        }
      }
    }
  } else {
    foreach ($customers as $customer) {
      if ($customer['customer_email'] == $field_list[$field_name]) {
        $errors[$field_name] = 'Existing email, use another one!';
        return false;
      }
    }
  }

  if (preg_match('/\s/', $field_list[$field_name])) {
    $errors[$field_name] = 'Input cannot contain spaces!';
    return false;
  }

  $pattern = '/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/';
  if (!preg_match($pattern, $field_list[$field_name])) {
    $errors[$field_name] = 'Incorrect email format!';
    return false;
  }

  return true;
}

function validate_email_staff(&$errors, $field_list, $field_name)
{
  if (!is_filled($field_list[$field_name])) {
    $errors[$field_name] = 'Required to fill!';
    return false;
  }

  $staffs = get_staffs();

  foreach ($staffs as $staff) {
    if ($staff['staff_email'] == $field_list[$field_name]) {
      $errors[$field_name] = 'Existing email, use another one!';
      return false;
    }
  }

  if (preg_match('/\s/', $field_list[$field_name])) {
    $errors[$field_name] = 'Input cannot contain spaces!';
    return false;
  }

  $pattern = '/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/';
  if (!preg_match($pattern, $field_list[$field_name])) {
    $errors[$field_name] = 'Input cannot contain spaces!';
    return false;
  }

  return true;
}

function validate_password(&$errors, $field_list, $field_name)
{
  if (!is_filled($field_list[$field_name])) {
    $errors[$field_name] = 'Required to fill!';
    return false;
  }

  if (strlen($field_list[$field_name]) < 8 || strlen($field_list[$field_name]) > 16) {
    $errors[$field_name] = 'Password length 8 to 16 characters!';
    return false;
  }

  if (!preg_match('/[A-Z]/', $field_list[$field_name])) {
    $errors[$field_name] = 'There must be at least 1 uppercase letter!';
    return false;
  }

  if (!preg_match('/[a-z]/', $field_list[$field_name])) {
    $errors[$field_name] = 'There must be at least 1 uppercase letter!';
    return false;
  }

  if (!preg_match('/\W/', $field_list[$field_name])) {
    $errors[$field_name] = 'There must be at least 1 special character!';
    return false;
  }

  if (preg_match('/\s/', $field_list[$field_name])) {
    $errors[$field_name] = 'Input cannot contain spaces!';
    return false;
  }

  return true;
}

function validate_num(&$errors, $field_list, $field_name)
{
  if (!is_filled($field_list[$field_name])) {
    $errors[$field_name] = 'Required to fill!';
    return false;
  }

  $pattern =  "/^[\d]{1,}$/";
  if (!preg_match($pattern, $field_list[$field_name])) {
    $errors[$field_name] = 'Input must be a number!';
    return false;
  }

  return true;
}

function validate_address(&$errors, $field_list, $field_name)
{
  if (!is_filled($field_list[$field_name])) {
    $errors[$field_name] = 'Required to fill!';
    return false;
  }

  return true;
}
