<?php

error_reporting(E_ALL);

require_once(__DIR__ . '/../config/database.php');

function find_item($id)
{
  try {
    $db = new PDO('mysql:host=localhost;dbname=' . DB_NAME, DB_USERNAME, DB_PASSWORD, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
    $statement = $db->prepare("SELECT * FROM items WHERE item_id = :id");
    $statement->bindValue(":id", $id);
    $statement->execute();

    $item = $statement->fetch(PDO::FETCH_ASSOC);

    return $item;
  } catch (PDOException $error) {
    echo $error->getMessage();
  }
}

function search_items_with_category($keyword = '', $category_id = '', $only_available = false)
{
  try {
    $db = new PDO('mysql:host=localhost;dbname=' . DB_NAME, DB_USERNAME, DB_PASSWORD, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);

    $query = "SELECT * FROM items INNER JOIN categories ON categories.category_id = items.category_id WHERE item_name LIKE :keyword";
    if ($category_id != '') {
      $query .= " AND items.category_id = :category_id";
    }
    if ($only_available) {
      $query .= " AND item_stock > 0";
    }
    $query .= ' ORDER BY item_id DESC';

    $statement = $db->prepare($query);
    $statement->bindValue(':keyword', "%$keyword%");
    if ($category_id != '') {
      $statement->bindValue(':category_id', $category_id);
    }
    $statement->execute();

    $items = $statement->fetchAll(PDO::FETCH_ASSOC);

    return $items;
  } catch (PDOException $error) {
    echo $error->getMessage();
  }
}

function get_items_with_category()
{
  try {
    $db = new PDO('mysql:host=localhost;dbname=' . DB_NAME, DB_USERNAME, DB_PASSWORD, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
    $statement = $db->prepare("SELECT * FROM items INNER JOIN categories ON categories.category_id = items.category_id ORDER BY item_id DESC");
    $statement->execute();

    $items = $statement->fetchAll(PDO::FETCH_ASSOC);

    return $items;
  } catch (PDOException $error) {
    echo $error->getMessage();
  }
}

function save_item($item)
{
  try {
    $db = new PDO('mysql:host=localhost;dbname=' . DB_NAME, DB_USERNAME, DB_PASSWORD, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
    $statement = $db->prepare("INSERT INTO items (supplier_id, category_id, item_name, item_price, item_stock, item_photo) VALUES (:supplier_id, :category_id, :name, :price, :stock, :photo)");
    $statement->bindValue(":supplier_id", trim($item['supplier_id']));
    $statement->bindValue(":category_id", trim($item['category_id']));
    $statement->bindValue(":name", htmlspecialchars(trim($item['name'])));
    $statement->bindValue(":price", trim($item['price']));
    $statement->bindValue(":stock", trim($item['stock']));
    $statement->bindValue(":photo", trim($item['photo']));
    $statement->execute();
  } catch (PDOException $error) {
    echo $error->getMessage();
  }
}

function update_item($id, $item)
{
  try {
    $db = new PDO('mysql:host=localhost;dbname=' . DB_NAME, DB_USERNAME, DB_PASSWORD, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
    $statement = $db->prepare("UPDATE items SET supplier_id = :supplier_id, category_id = :category_id, item_name = :name, item_price = :price, item_stock = :stock, item_photo = :photo WHERE item_id = :id");
    $statement->bindValue(":id", $id);
    $statement->bindValue(":supplier_id", trim($item['supplier_id']));
    $statement->bindValue(":category_id", trim($item['category_id']));
    $statement->bindValue(":name", htmlspecialchars(trim($item['name'])));
    $statement->bindValue(":price", trim($item['price']));
    $statement->bindValue(":stock", trim($item['stock']));
    $statement->bindValue(":photo", trim($item['photo']));
    $statement->execute();
  } catch (PDOException $error) {
    echo $error->getMessage();
  }
}

function delete_item($id)
{
  try {
    $db = new PDO('mysql:host=localhost;dbname=' . DB_NAME, DB_USERNAME, DB_PASSWORD, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
    $statement = $db->prepare("DELETE FROM items WHERE item_id = :id");
    $statement->bindValue(":id", $id);
    $statement->execute();
  } catch (PDOException $error) {
    echo $error->getMessage();
  }
}

function count_related_items_based_on_category($category_id)
{
  try {
    $db = new PDO('mysql:host=localhost;dbname=' . DB_NAME, DB_USERNAME, DB_PASSWORD, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
    $statement = $db->prepare("SELECT COUNT(*) AS count_related_items FROM items WHERE category_id = :category_id");
    $statement->bindValue(":category_id", $category_id);
    $statement->execute();

    $item = $statement->fetch(PDO::FETCH_ASSOC);

    return $item;
  } catch (PDOException $error) {
    echo $error->getMessage();
  }
}
