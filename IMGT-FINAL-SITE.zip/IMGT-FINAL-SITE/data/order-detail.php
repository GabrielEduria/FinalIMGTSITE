<?php

error_reporting(E_ALL);

require_once(__DIR__ . '/../config/database.php');
require_once(__DIR__ . '/cart-item.php');

function get_order_details_with_item_with_category($order_id)
{
  try {
    $db = new PDO('mysql:host=localhost;dbname=' . DB_NAME, DB_USERNAME, DB_PASSWORD, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
    $statement = $db->prepare("SELECT * FROM order_details INNER JOIN items ON items.item_id = order_details.item_id INNER JOIN categories ON categories.category_id = items.category_id WHERE order_id = :order_id ORDER BY order_detail_id DESC");
    $statement->bindValue(":order_id", $order_id);
    $statement->execute();

    $order_details = $statement->fetchAll(PDO::FETCH_ASSOC);

    return $order_details;
  } catch (PDOException $error) {
    throw new Exception($error->getMessage());
  }
}

function save_order_detail($order_id, $item_id, $order_detail)
{
  try {
    $db = new PDO('mysql:host=localhost;dbname=' . DB_NAME, DB_USERNAME, DB_PASSWORD, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
    $statement = $db->prepare("INSERT INTO order_details (order_id, item_id, order_detail_qty, order_detail_unit_price) VALUES (:order_id, :item_id, :qty, :unit_price)");
    $statement->bindValue(":order_id", $order_id);
    $statement->bindValue(":item_id", $item_id);
    $statement->bindValue(":qty", $order_detail['qty']);
    $statement->bindValue(":unit_price", $order_detail['unit_price']);
    $statement->execute();
  } catch (PDOException $error) {
    throw new Exception($error->getMessage());
  }
}
