<?php

error_reporting(E_ALL);

require_once(__DIR__ . '/../config/database.php');

function get_cart_items_with_item($customer_id)
{
  try {
    $db = new PDO('mysql:host=localhost;dbname=' . DB_NAME, DB_USERNAME, DB_PASSWORD, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
    $statement = $db->prepare("SELECT * FROM cart_items INNER JOIN items ON items.item_id = cart_items.item_id WHERE customer_id = :customer_id ORDER BY cart_items.item_id DESC");
    $statement->bindValue(":customer_id", $customer_id);
    $statement->execute();

    $cart_items = $statement->fetchAll(PDO::FETCH_ASSOC);

    return $cart_items;
  } catch (PDOException $error) {
    throw new Exception($error->getMessage());
  }
}

function get_cart_items_with_item_with_category($customer_id)
{
  try {
    $db = new PDO('mysql:host=localhost;dbname=' . DB_NAME, DB_USERNAME, DB_PASSWORD, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
    $statement = $db->prepare("SELECT * FROM cart_items INNER JOIN items ON items.item_id = cart_items.item_id INNER JOIN categories ON categories.category_id = items.category_id WHERE customer_id = :customer_id ORDER BY cart_items.item_id DESC");
    $statement->bindValue(":customer_id", $customer_id);
    $statement->execute();

    $cart_items = $statement->fetchAll(PDO::FETCH_ASSOC);

    return $cart_items;
  } catch (PDOException $error) {
    throw new Exception($error->getMessage());
  }
}

function find_cart_item($customer_id, $item_id)
{
  try {
    $db = new PDO('mysql:host=localhost;dbname=' . DB_NAME, DB_USERNAME, DB_PASSWORD, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
    $statement = $db->prepare("SELECT * FROM cart_items WHERE customer_id = :customer_id AND item_id = :item_id");
    $statement->bindValue(":customer_id", $customer_id);
    $statement->bindValue(":item_id", $item_id);
    $statement->execute();

    $cart_item = $statement->fetch(PDO::FETCH_ASSOC);

    return $cart_item;
  } catch (PDOException $error) {
    throw new Exception($error->getMessage());
  }
}

function save_cart_item($customer_id, $item_id)
{
  try {
    $db = new PDO('mysql:host=localhost;dbname=' . DB_NAME, DB_USERNAME, DB_PASSWORD, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
    $statement = $db->prepare("INSERT INTO cart_items (customer_id, item_id, cart_item_qty) VALUES (:customer_id, :item_id, 1)");
    $statement->bindValue(":customer_id", $customer_id);
    $statement->bindValue(":item_id", $item_id);
    $statement->execute();
  } catch (PDOException $error) {
    throw new Exception($error->getMessage());
  }
}

function update_cart_item($customer_id, $item_id, $qty)
{
  try {
    $db = new PDO('mysql:host=localhost;dbname=' . DB_NAME, DB_USERNAME, DB_PASSWORD, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
    $statement = $db->prepare("UPDATE cart_items SET cart_item_qty = :qty WHERE customer_id = :customer_id AND item_id = :item_id");
    $statement->bindValue(":qty", $qty);
    $statement->bindValue(":customer_id", $customer_id);
    $statement->bindValue(":item_id", $item_id);
    $statement->execute();
  } catch (PDOException $error) {
    throw new Exception($error->getMessage());
  }
}

function delete_cart_item($customer_id, $item_id)
{
  try {
    $db = new PDO('mysql:host=localhost;dbname=' . DB_NAME, DB_USERNAME, DB_PASSWORD, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
    $statement = $db->prepare("DELETE FROM cart_items WHERE customer_id = :customer_id AND item_id = :item_id");
    $statement->bindValue(":customer_id", $customer_id);
    $statement->bindValue(":item_id", $item_id);
    $statement->execute();
  } catch (PDOException $error) {
    throw new Exception($error->getMessage());
  }
}

function delete_all_cart_items($customer_id)
{
  try {
    $db = new PDO('mysql:host=localhost;dbname=' . DB_NAME, DB_USERNAME, DB_PASSWORD, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
    $statement = $db->prepare("DELETE FROM cart_items WHERE customer_id = :customer_id");
    $statement->bindValue(":customer_id", $customer_id);
    $statement->execute();
  } catch (PDOException $error) {
    throw new Exception($error->getMessage());
  }
}
