<?php

session_start();

if (!isset($_SESSION['customer_id'])) {
  header("Location: ./login.php");
  exit();
}

require_once('data/item.php');
require_once('data/category.php');

$keyword = htmlspecialchars(isset($_GET['keyword']) ? $_GET['keyword'] : '');
$category_id = isset($_GET['category_id']) ? $_GET['category_id'] : '';

$categories = get_categories();
$items = search_items_with_category($keyword, $category_id, true);

require('layouts/header.php');

?>

<main>
  <form action="./products.php" method="get" class="filter container">
    <div class="filter__list">
      <div class="filter__item">
        <label for="category_id">
          <i class="ph ph-tag"></i>
        </label>
        <select name="category_id" id="category_id">
          <option value="" selected>All</option>
          <?php foreach ($categories as $category) : ?>
            <option value="<?= $category['category_id'] ?>" <?= $category['category_id'] == $category_id ? 'selected' : '' ?>><?= $category['category_name'] ?></option>
          <?php endforeach; ?>
        </select>
      </div>
    </div>
    <div class="filter__search">
      <label for="keyword">
        <i class="ph ph-magnifying-glass"></i>
      </label>
      <input type="search" name="keyword" id="keyword" placeholder="Search ..." value="<?= $keyword ?>" />
      <button type="submit">Search</button>
    </div>
  </form>
  <div class="products container">
    <div class="products__body">
      <?php foreach ($items as $item) : ?>
        <div class="products__card">
          <div class="products__card-top">
            <img src="./assets/img/items/<?= $item['item_photo'] ?>" alt="<?= $item['item_name'] ?>" class="products__card-img" />
          </div>
          <div class="products__card-body">
            <p class="products__card-price">₱<?= number_format($item['item_price']) ?></p>
            <h3 class="products__card-name"><?= $item['item_name'] ?></h3>
            <p class="products__card-info">
              <i class="ph ph-tag"></i>
              <?= $item['category_name'] ?>
              <i class="ph ph-package"></i>
              <?= $item['item_stock'] ?> Stock
            </p>
            <hr />
            <form action="./add-to-cart.php" method="post" class="products__card-actions">
              <input type="hidden" name="item_id" value="<?= $item['item_id'] ?>">
              <button type="submit" name="buy_now" class="products__card-action-button products__card-action-button_primary">
                <i class="ph ph-shopping-cart-simple"></i>
                Add to Cart
              </button>
            </form>
          </div>
        </div>
      <?php endforeach; ?>
      <?php if (empty($items)) : ?>
        <div class="products__empty">
          Produk kosong!
        </div>
      <?php endif; ?>
    </div>
  </div>
</main>

<?php

require('layouts/footer.php');

?>