<?php

session_start();

if (!isset($_SESSION['staff_id'])) {
  header("Location: ./login.php");
  exit();
}

if ($_SESSION['role_name'] != 'administrator') {
  header("Location: ./index.php");
  exit();
}

if (!isset($_GET['item_id'])) {
  header("Location: ./products.php");
  exit();
}

require_once('../data/item.php');
require_once('../libs/file.php');

$item = find_item($_GET['item_id']);

if (!$item) {
  header("Location: ./products.php");
  exit();
}

delete_item($_GET['item_id']);
delete_file($item['item_photo'], 'items');

header('Location: ./products.php');
exit();
