<?php

session_start();

if (!isset($_SESSION['staff_id'])) {
  header("Location: ./login.php");
  exit();
}

if ($_SESSION['role_name'] != 'administrator') {
  header("Location: ./index.php");
  exit();
}

require_once('../data/supplier.php');

$suppliers = get_suppliers();

$page = 'suppliers';
require('layouts/header.php');

?>

<div class="admin">
  <div class="admin__header">
    <h1 class="admin__title">Supplier</h1>
    <div class="admin__actions">
      <a href="./supplier-add.php" class="admin__button">Add Supplier</a>
    </div>
  </div>
  <div class="admin__body">
    <div class="admin__card">
      <table>
        <thead>
          <tr>
            <th>No.</th>
            <th>Name</th>
            <th>Phone</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($suppliers as $i => $supplier) : ?>
            <tr>
              <td><?= $i + 1 ?>.</td>
              <td>
                <a href="./supplier-single.php?supplier_id=<?= $supplier['supplier_id'] ?>"><?= $supplier['supplier_name'] ?></a>
              </td>
              <td><?= $supplier['supplier_phone'] ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php

require('layouts/footer.php');

?>