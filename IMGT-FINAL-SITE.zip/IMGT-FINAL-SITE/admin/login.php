<?php

session_start();


if (isset($_SESSION['staff_id'])) {
  header("Location: ./index.php");
  exit();
}

require_once('../data/staff.php');
require_once('../libs/validation.php');


$login_error = null;
$errors = [];
$old_inputs = [
  'email' => '',
];


if (isset($_POST['submit'])) {
  validate_email($errors, $_POST, 'email');
  validate_password($errors, $_POST, 'password');


  if (!$errors) {
    $staff = find_staff_with_role($_POST['email']);

    
    if ($staff) {
    
      if (password_verify($_POST['password'], $staff['staff_password'])) {
        $_SESSION['role_name'] = $staff['role_name'];
        $_SESSION['staff_id'] = $staff['staff_id'];
        $_SESSION['staff_name'] = $staff['staff_name'];

        header("Location: ./index.php");
        exit();
      }
    }

    $login_error = 'Incorrect email or password!';
  }

  $old_inputs['email'] = htmlspecialchars($_POST['email']);
}


require('layouts/header-two.php');

?>


<link rel="stylesheet" href="../assets/css/register.css">


<main>
  
  <div class="register container">
    <form action="./login.php" method="post" class="register__form">
      <h1>Login Staff</h1>
      <?php if ($login_error != null) : ?>
        <div class="alert alert_danger">
          <?= $login_error; ?>
        </div>
      <?php endif; ?>
      <?php if (isset($_GET['success_message'])) : ?>
        <div class="alert alert_success">
          <?= $_GET['success_message']; ?>
        </div>
      <?php endif; ?>
      <div>
        <label for="email" class="input-label">Email <span class="text-danger">*</span></label>
        <input type="text" name="email" id="email" class="input" value="<?= $old_inputs['email'] ?>" />
        <?php if (isset($errors['email'])) : ?>
          <div class="input-error"><?= $errors['email'] ?></div>
        <?php endif ?>
      </div>
      <div>
        <label for="password" class="input-label">Password <span class="text-danger">*</span></label>
        <input type="password" name="password" id="password" class="input" />
        <div class="input-help">Must contain 8-16 characters with a minimum of 1 uppercase letter, 1 lowercase letter, 1 special character, and must not contain spaces.</div>
        <?php if (isset($errors['password'])) : ?>
          <div class="input-error"><?= $errors['password'] ?></div>
        <?php endif ?>
      </div>
      <button type="submit" name="submit" class="register__button">Login</button>
      <p>
        <a href="../login.php">Login Customer</a>
      </p>
    </form>
  </div>
 
</main>


<?php


require('layouts/footer-two.php');

?>