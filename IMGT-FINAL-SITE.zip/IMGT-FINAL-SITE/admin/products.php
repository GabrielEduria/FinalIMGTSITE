<?php

session_start();

if (!isset($_SESSION['staff_id'])) {
  header("Location: ./login.php");
  exit();
}

if ($_SESSION['role_name'] != 'administrator') {
  header("Location: ./index.php");
  exit();
}

require_once('../data/item.php');

$items = get_items_with_category();

$page = 'products';
require('layouts/header.php');

?>

<div class="admin">
  <div class="admin__header">
    <h1 class="admin__title"><?= $title ?></h1>
    <div class="admin__actions">
      <a href="./product-add.php" class="admin__button">Add Item</a>
    </div>
  </div>
  <div class="admin__body">
    <div class="admin__card">
      <table>
        <thead>
          <tr>
            <th>No.</th>
            <th>Name</th>
            <th>Price</th>
            <th>Stock</th>
            <th>Category</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($items as $i => $item) : ?>
            <tr>
              <td><?= $i + 1 ?>.</td>
              <td><a href="./product-single.php?item_id=<?= $item['item_id'] ?>"><?= $item['item_name'] ?></a></td>
              <td>₱<?= number_format($item['item_price']) ?></td>
              <td><?= $item['item_stock'] ?></td>
              <td><?= $item['category_name'] ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php

require('layouts/footer.php');

?>