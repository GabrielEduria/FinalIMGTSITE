<?php

session_start();

if (!isset($_SESSION['staff_id'])) {
  header("Location: ./login.php");
  exit();
}

if ($_SESSION['role_name'] != 'administrator') {
  header("Location: ./index.php");
  exit();
}

if (!isset($_GET['item_id'])) {
  header("Location: ./products.php");
  exit();
}

require_once('../data/category.php');
require_once('../data/item.php');
require_once('../data/supplier.php');
require_once('../libs/validation.php');
require_once('../libs/file.php');

$item = find_item($_GET['item_id']);
$categories = get_categories();
$suppliers = get_suppliers();

if (!$item) {
  header("Location: ./products.php");
  exit();
}

$errors = [];
$old_inputs = [
  'supplier_id' => $item['supplier_id'],
  'category_id' => $item['category_id'],
  'name' => $item['item_name'],
  'price' => $item['item_price'],
  'stock' => $item['item_stock'],
];

if (isset($_POST['submit'])) {
  validate_num($errors, $_POST, 'supplier_id');
  validate_num($errors, $_POST, 'category_id');
  validate_name($errors, $_POST, 'name');
  validate_num($errors, $_POST, 'price');
  validate_num($errors, $_POST, 'stock');

  if (!$errors) {
    $filename = upload_file($_FILES, 'photo', 'items');

    if ($filename) {
      $_POST['photo'] = $filename;
      delete_file($item['item_photo'], 'items');
    } else {
      $_POST['photo'] = $item['item_photo'];
    }

    update_item($item['item_id'], $_POST);
    header('Location: ./products.php');
    exit();
  }

  $old_inputs['supplier_id'] = htmlspecialchars($_POST['supplier_id']);
  $old_inputs['category_id'] = htmlspecialchars($_POST['category_id']);
  $old_inputs['name'] = htmlspecialchars($_POST['name']);
  $old_inputs['price'] = htmlspecialchars($_POST['price']);
  $old_inputs['stock'] = htmlspecialchars($_POST['stock']);
}

$page = 'products';
require('layouts/header.php');

?>

<link rel="stylesheet" href="../assets/css/admin/page-single.css">

<div class="admin">
  <div class="admin__header">
    <div class="admin__back">
      <i class="ph-bold ph-arrow-left"></i>
      <a href="./products.php">Back</a>
    </div>
    <h1 class="admin__title">Item Details</h1>
  </div>
  <div class="admin__body">
    <div class="admin__card">
      <form action="./product-single.php?item_id=<?= $item['item_id'] ?>" method="post" class="page-single" enctype="multipart/form-data">
        <img src="../assets/img/items/<?= $item['item_photo'] ?>" alt="<?= $item['item_name'] ?>" class="page-single__img" />
        <div>
          <label for="name" class="input-label">Name <span class="text-danger">*</span></label>
          <input type="text" id="name" name="name" class="input" value="<?= $old_inputs['name'] ?>" />
          <?php if (isset($errors['name'])) : ?>
            <div class="input-error">
              <?= $errors['name'] ?>
            </div>
          <?php endif; ?>
        </div>
        <div>
          <label for="price" class="input-label">Price <span class="text-danger">*</span></label>
          <input type="text" id="price" name="price" class="input" value="<?= $old_inputs['price'] ?>" />
          <?php if (isset($errors['price'])) : ?>
            <div class="input-error">
              <?= $errors['price'] ?>
            </div>
          <?php endif; ?>
        </div>
        <div>
          <label for="category_id" class="input-label">Category <span class="text-danger">*</span></label>
          <select name="category_id" id="category_id" class="input-select">
            <?php foreach ($categories as $category) : ?>
              <option value="<?= $category['category_id'] ?>" <?= $category['category_id'] == $old_inputs['category_id'] ? 'selected' : '' ?>><?= $category['category_name'] ?></option>
            <?php endforeach; ?>
          </select>
          <?php if (isset($errors['category_id'])) : ?>
            <div class="input-error">
              <?= $errors['category_id'] ?>
            </div>
          <?php endif; ?>
        </div>
        <div>
          <label for="supplier_id" class="input-label">Supplier <span class="text-danger">*</span></label>
          <select name="supplier_id" id="supplier_id" class="input-select">
            <?php foreach ($suppliers as $supplier) : ?>
              <option value="<?= $supplier['supplier_id'] ?>" <?= $supplier['supplier_id'] == $old_inputs['supplier_id'] ? 'selected' : '' ?>><?= $supplier['supplier_name'] ?></option>
            <?php endforeach; ?>
          </select>
          <?php if (isset($errors['supplier_id'])) : ?>
            <div class="input-error">
              <?= $errors['supplier_id'] ?>
            </div>
          <?php endif; ?>
        </div>
        <div>
          <label for="stock" class="input-label">Stock <span class="text-danger">*</span></label>
          <input type="text" id="stock" name="stock" class="input" value="<?= $old_inputs['stock'] ?>" />
          <?php if (isset($errors['stock'])) : ?>
            <div class="input-error">
              <?= $errors['stock'] ?>
            </div>
          <?php endif; ?>
        </div>
        <div>
          <label for="photo" class="input-label">Photo</label>
          <input type="file" id="photo" name="photo" class="input" />
          <?php if (isset($errors['photo'])) : ?>
            <div class="input-error">
              <?= $errors['photo'] ?>
            </div>
          <?php endif; ?>
        </div>
        <div class="page-single__actions-container">
          <a href="./product-delete.php?item_id=<?= $item['item_id'] ?>" class="page-single__button">Wipe</a>
          <div class="page-single__actions">
            <a href="./products.php" class="page-single__button">Cancel</a>
            <button type="submit" name="submit" class="page-single__button page-single__button_primary">
              Add
            </button>
          </div>
        </div>
      </form>
    </div>
  </div>
</div>

<?php

require('layouts/footer.php');

?>