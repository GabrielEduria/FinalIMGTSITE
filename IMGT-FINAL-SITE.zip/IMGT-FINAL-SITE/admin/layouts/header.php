<!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <title><?= isset($title) ? $title . ' - ' : ''; ?>Luci Moto</title>

  <link rel="stylesheet" href="../assets/css/style.css" />
  <link rel="stylesheet" href="../assets/css/admin/admin.css" />


  <link rel="shortcut icon" href="../assets/img/slider-image1.png" type="image/x-icon" />
</head>

<body class="body_light">

  <?php require('layouts/sidebar.php') ?>

  <div class="page-wrapper">

    <?php require('layouts/topbar.php') ?>

    <div class="content">
      <div class="container container_admin content__container">
        <div class="content__main">