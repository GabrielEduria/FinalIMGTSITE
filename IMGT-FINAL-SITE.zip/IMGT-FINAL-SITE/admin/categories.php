<?php

session_start();

if (!isset($_SESSION['staff_id'])) {
  header("Location: ./login.php");
  exit();
}

if ($_SESSION['role_name'] != 'administrator') {
  header("Location: ./index.php");
  exit();
}

require_once('../data/category.php');
require_once('../data/item.php');

$categories = get_categories();

$page = 'categories';
require('layouts/header.php');

?>

<div class="admin">
  <div class="admin__header">
    <h1 class="admin__title">Category</h1>
    <div class="admin__actions">
      <a href="./category-add.php" class="admin__button">Add Category</a>
    </div>
  </div>
  <div class="admin__body">
    <div class="admin__card">
      <table>
        <thead>
          <tr>
            <th>No.</th>
            <th>Name</th>
            <th>Related Category</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($categories as $i => $category) : ?>
            <tr>
              <td><?= $i + 1 ?>.</td>
              <td>
                <a href="./category-single.php?category_id=<?= $category['category_id'] ?>"><?= $category['category_name'] ?></a>
              </td>
              <td><?= count_related_items_based_on_category($category['category_id'])['count_related_items'] ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php

require('layouts/footer.php');

?>