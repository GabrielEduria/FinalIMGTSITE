<?php

error_reporting(E_ALL);
session_start();

if (!isset($_SESSION['staff_id'])) {
  header("Location: ./login.php");
  exit();
}

require_once('../config/database.php');

try {
  $pdo = new PDO('mysql:host=localhost;dbname=' . DB_NAME, DB_USERNAME, DB_PASSWORD, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
  $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
  die('Connection failed: ' . $e->getMessage());
}

$transid = isset($_GET['transid']) ? $_GET['transid'] : null;

$dateorderstmt = $pdo->prepare("SELECT order_date FROM order_details ordet, orders ord WHERE ord.order_id = ?");
$dateorderstmt->execute([$transid]);
$dateorder = $dateorderstmt->fetch(PDO::FETCH_ASSOC)['order_date'];

$itemstmt = $pdo->prepare("SELECT item_name, item_price, order_detail_qty FROM order_details ordet, items pl WHERE ordet.item_id = pl.item_id AND order_id = ? ORDER BY order_detail_unit_price");
$itemstmt->execute([$transid]);

$itemquantityarray = array();
$itempricearray = array();
$itemnamearray = array();

while ($row = $itemstmt->fetch(PDO::FETCH_ASSOC)) {
  array_push($itemquantityarray, $row['order_detail_qty']);
  array_push($itempricearray, $row['item_price']);
  array_push($itemnamearray, $row['item_name']);
}

$len = count($itemnamearray);
$drop = $len + 1;
$totalprice = 0;
$totalquantity = 0;

$page = 'paid-transactions';
$title = 'Detail Transaksi Lunas';
require('layouts/header.php');

?>

<link rel="stylesheet" href="../assets/css/admin/page-single.css">

<div class="admin">
  <div class="admin__header">
    <div class="admin__back">
      <i class="ph-bold ph-arrow-left"></i>
      <a href="./paid-transactions.php">Kembali</a>
    </div>
    <h1 class="admin__title">Detail transaksi lunas</h1>
  </div>
  <div class="admin__body">
    <div class="admin__card">
      <?php
      echo "<p>Tanggal transaksi: " . date('d M Y', strtotime($dateorder)) . "</p>";
      ?>
    </div>
    <div class="admin__card">
      <table>
        <?php
        for ($rait = 0; $rait <= $drop; $rait++) {
          for ($don = 0; $don <= 4; $don++) {
            if ($rait == 0) {
              if ($don == 0) {
                echo "<thead><tr><th>No.</th>";
              } else if ($don == 1) {
                echo '<th>Tanaman</th>';
              } else if ($don == 2) {
                echo '<th>Harga</th>';
              } else if ($don == 3) {
                echo '<th>Kuantitas</th>';
              } else {
                echo '<th>Subtotal</th>';
              }
            } else if ($rait == $drop) {
              if ($don == 0) {
                echo '<tfoot><tr><td>Total</td>';
              } else if ($don == 3) { 
                echo "<td>$totalquantity</td>";
              } else if ($don == 4) { 
                echo "<td>Rp" . number_format($totalprice) . "</td></tfoot>";
              } else {
                echo '<td> </td>';
              }
            } else if ($don == 0 && $rait != 0) {
              if ($rait != $drop) {
                if ($rait == 1) {
                  echo '<tbody><tr><td>' . $rait . '</td>';
                } else {
                  echo '<tr><td>' . $rait . '</td>';
                }
              }
            } else if ($don == 1 && $rait != 0 && $rait != $drop) { 
              echo '<td>' . $itemnamearray[$rait - 1] . '</td>';
            } else if ($don == 2 && $rait != 0 && $rait != $drop) { 
              echo '<td>Rp' . number_format($itempricearray[$rait - 1]) . '</td>';
            } else if ($don == 3 && $rait != 0 && $rait != $drop) { 
              echo '<td>' . $itemquantityarray[$rait - 1] . '</td>';
              $totalquantity += $itemquantityarray[$rait - 1];
            } else {
              if ($rait != $len) { 
                echo '<td>Rp' . number_format($itempricearray[$rait - 1] * $itemquantityarray[$rait - 1]) . '</td>';
                $totalprice = $totalprice + $itempricearray[$rait - 1] * $itemquantityarray[$rait - 1];
              } else if ($rait == $len) {
                echo '<td>Rp' . number_format($itempricearray[$rait - 1] * $itemquantityarray[$rait - 1]) . '</td><tbody>';
                $totalprice = $totalprice + $itempricearray[$rait - 1] * $itemquantityarray[$rait - 1];
              } else {
                echo '<td> </td>';
              }
            }
          }
        }
        ?>
      </table>
    </div>
  </div>
</div>


<?php


require('layouts/footer.php');

?>