<?php

session_start();

if (!isset($_SESSION['staff_id'])) {
  header("Location: ./login.php");
  exit();
}

if ($_SESSION['role_name'] != 'administrator') {
  header("Location: ./index.php");
  exit();
}

require_once('../data/transaction.php');

$order_info = get_data_order();

$page = 'unpaid-transactions';
require('layouts/header.php');

?>

<div class="admin">
  <div class="admin__header">
    <h1 class="admin__title">In Process</h1>
  </div>
  <div class="admin__body">
    <div class="admin__card">
      <table>
        <thead>
          <tr>
            <th>Transaction No.</th>
            <th>Payment Method</th>
            <th>Date</th>
            <th>Total Items</th>
            <th>Total Price</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($order_info as $order) : ?>
            <tr>
              <td>#<?= $order["order_id"] ?></td>
              <td><?= $order["payment_method_bank"] ?></td>
              <td><?= date('d M Y', strtotime($order["order_date"])) ?></td>
              <td><?= get_order_sum($order["order_id"]) ?></td>
              <td>₱<?= number_format($order["order_total_price"]) ?></td>
              <td>
                <a href="./unpaid-transaction-approved.php?order_id=<?= $order["order_id"] ?>" class="button">Mark as paid</a>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php

require('layouts/footer.php');

?>