<?php

define('DB_NAME', 'store');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
