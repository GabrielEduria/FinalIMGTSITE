<?php

define('STAFF_ADMINISTRATOR_TOKEN', '2s93kl');
define('STAFF_MANAGER_TOKEN', '943il2');
