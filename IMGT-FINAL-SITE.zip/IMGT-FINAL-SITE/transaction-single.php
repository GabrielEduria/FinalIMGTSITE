<?php

session_start();

if (!isset($_SESSION['customer_id'])) {
  header("Location: ./login.php");
  exit();
}

if (!isset($_GET['order_id'])) {
  header("Location: ./transactions.php");
  exit();
}

require_once('data/order.php');
require_once('data/order-detail.php');

$order = find_order_with_payment_method($_SESSION['customer_id'], $_GET['order_id']);

if (!$order) {
  header("Location: ./transactions.php");
  exit();
}

$order_details = get_order_details_with_item_with_category($order['order_id']);

require('layouts/header.php');

?>

<link rel="stylesheet" href="./assets/css/transaction-single.css">

<main>
  <div class="transaction-single">
    <div class="transaction-single__header">
      <h1>
        Transaction #<?= $order['order_id'] ?> <span class="badge <?= $order['order_status'] == 'paid' ? 'badge_success' : 'badge_danger' ?>"><?= ucwords($order['order_status']) ?></span>
      </h1>
      <p><?= date('d F Y', strtotime($order['order_date'])) ?></p>
    </div>
    <div class="transaction-single__body">
      <div class="transaction-single__list">
        <?php $total = 0; ?>
        <?php foreach ($order_details as $order_detail) : ?>
          <?php
          $subtotal =  $order_detail['item_price'] * $order_detail['order_detail_qty'];
          $total += $subtotal;
          ?>
          <div class="transaction-single__item">
            <div class="transaction-single__item-left">
              <img src="./assets/img/items/<?= $order_detail['item_photo'] ?>" alt="<?= $order_detail['item_name'] ?>" />
              <div class="transaction-single__item-left-text">
                <h2><?= $order_detail['item_name'] ?></h2>
                <p><?= $order_detail['category_name'] ?></p>
                <span>₱<?= number_format($order_detail['order_detail_unit_price']) ?> x <?= $order_detail['order_detail_qty'] ?></span>
              </div>
            </div>
            <div class="transaction-single__item-right">
              <p>₱<?= number_format($subtotal) ?></p>
            </div>
          </div>
          <hr />
        <?php endforeach; ?>
        <div class="transaction-single__item">
          <div class="transaction-single__item-left">
            <h2>Total</h2>
          </div>
          <div class="transaction-single__item-right">
            <p>₱<?= number_format($total) ?></p>
          </div>
        </div>
      </div>
      <div class="transaction-single__method">
        <div class="transaction-single__method-group">
          <h2 class="transaction-single__method-title">Payment Method</h2>
          <div class="transaction-single__method-list">
            <div class="transaction-single__method-item">
              <img src="./assets/img/banks/<?= $order['payment_method_logo'] ?>" alt="<?= $order['payment_method_bank'] ?>" />
            </div>
          </div>
          <p>
            <?= $order['payment_method_bank'] ?> <?= $order['payment_method_number'] ?> <br />
            a/n <?= $order['payment_method_name'] ?>
          </p>
          <?php if ($order['order_status'] == 'unpaid') : ?>
            <div>
              <a href="./transaction-edit-payment-method.php?order_id=<?= $order['order_id'] ?>">Change Payment Method</a>
            </div>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
</main>

<?php

require('layouts/footer.php');

?>